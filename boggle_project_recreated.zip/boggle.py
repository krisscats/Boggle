import random
import time
import pickle

# Load config
def load_config(file_name='config.txt'):
    with open(file_name, 'r', encoding='utf-8') as f:
        lines = f.read().strip().split('\n')
    time_limit = int(lines[0])
    dice = [line.split() for line in lines[1:17]]
    dictionary_file = lines[17].strip()
    return time_limit, dice, dictionary_file

# Load trie
def load_trie(file_name='trie_nested.pkl'):
    with open(file_name, 'rb') as f:
        trie = pickle.load(f)
    return trie

# Shuffle dice and roll to create board
def create_board(dice):
    random.shuffle(dice)
    board = []
    for die in dice:
        face = random.choice(die)
        board.append(face)
    # Create 4x4 matrix
    board_4x4 = [board[i*4:(i+1)*4] for i in range(4)]
    return board_4x4

# Print board nicely
def print_board(board):
    print("\nTablero Boggle:")
    for row in board:
        print(" ".join(f'{c:2}' for c in row))
    print("")

# Find neighbors positions for DFS
def neighbors(r, c):
    for dr in [-1, 0, 1]:
        for dc in [-1, 0, 1]:
            if dr == 0 and dc == 0:
                continue
            nr, nc = r + dr, c + dc
            if 0 <= nr < 4 and 0 <= nc < 4:
                yield nr, nc

# DFS search for word on board
def dfs(board, word, r, c, visited, idx):
    if idx == len(word):
        return True
    for nr, nc in neighbors(r, c):
        if (nr, nc) not in visited:
            cell = board[nr][nc].lower()
            # Special case for 'qu' which counts as two letters
            if word[idx:idx+2] == 'qu' and cell == 'qu':
                if dfs(board, word, nr, nc, visited | {(nr,nc)}, idx+2):
                    return True
            elif word[idx] == cell[0]:
                if dfs(board, word, nr, nc, visited | {(nr,nc)}, idx+1):
                    return True
    return False

# Check if word is on board
def word_on_board(board, word):
    word = word.lower()
    for r in range(4):
        for c in range(4):
            cell = board[r][c].lower()
            if word.startswith('qu') and cell == 'qu' and dfs(board, word, r, c, {(r,c)}, 2):
                return True
            elif cell == word[0] and dfs(board, word, r, c, {(r,c)}, 1):
                return True
    return False

# Score based on length
def score_word(word):
    length = len(word)
    if length < 3:
        return 0
    if length in [3,4]:
        return 1
    if length == 5:
        return 2
    if length == 6:
        return 3
    if length == 7:
        return 5
    if length >= 8:
        return 11

# Main game loop
def main():
    print("Bienvenido al juego Boggle en Español (Un Jugador)")
    time_limit, dice, dict_file = load_config()
    trie = load_trie()

    board = create_board(dice)
    print_board(board)

    start_time = time.time()
    entered_words = set()
    total_score = 0

    while True:
        remaining = int(time_limit - (time.time() - start_time))
        if remaining <= 0:
            print("\n¡Se acabó el tiempo!")
            break
        print(f"Tiempo restante: {remaining} segundos")
        word = input("Ingrese una palabra (o 'salir' para terminar): ").strip().lower()
        if word == 'salir':
            break
        if len(word) < 3:
            print("La palabra debe tener al menos 3 letras.")
            continue
        if word in entered_words:
            print("Palabra ya ingresada.")
            continue
        if not trie.search(word):
            print("Palabra no válida según el diccionario.")
            continue
        if not word_on_board(board, word):
            print("La palabra no se encuentra en el tablero según las reglas.")
            continue
        points = score_word(word)
        entered_words.add(word)
        total_score += points
        print(f"Palabra válida! Puntos obtenidos: {points} | Puntaje total: {total_score}")

    print(f"Juego terminado. Puntaje total: {total_score}")

if __name__ == '__main__':
    main()