import pickle

class TrieNode:
    def __init__(self):
        self.children = {}
        self.is_end_of_word = False

class Trie:
    def __init__(self):
        self.root = TrieNode()

    def insert(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                node.children[char] = TrieNode()
            node = node.children[char]
        node.is_end_of_word = True

    def search(self, word):
        node = self.root
        for char in word:
            if char not in node.children:
                return False
            node = node.children[char]
        return node.is_end_of_word

def load_words(file_path):
    words = []
    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            word = line.strip().lower()
            if word:
                words.append(word)
    return words

def main():
    words = load_words('diccionario.txt')
    trie = Trie()
    for word in words:
        trie.insert(word)
    with open('trie_nested.pkl', 'wb') as f:
        pickle.dump(trie, f)
    print("Trie built and saved to trie_nested.pkl")

if __name__ == '__main__':
    main()